/* FINBRAIN official brand-film v0.8.4 on Claude original site. */
(function () {
  'use strict';
  var video = document.getElementById('finbrainBrandFilm');
  var toggle = document.getElementById('finbrainFilmToggle');
  var hero = document.getElementById('finbrain-intro');
  if (!video || !toggle || !hero) return;
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  function updateButton() {
    toggle.textContent = video.paused ? '영상 재생' : '일시정지';
    toggle.setAttribute('aria-label', video.paused ? '영상 재생' : '영상 일시정지');
    toggle.setAttribute('aria-pressed', video.paused ? 'true' : 'false');
  }
  function syncEndCard() {
    var ending = !video.paused && video.currentTime >= 22.2;
    hero.classList.toggle('hero--end-card', ending);
  }
  function reportPlaybackError() {
    hero.classList.add('hero--video-error');
    hero.classList.remove('hero--end-card');
    toggle.hidden = true;
    hero.style.backgroundImage = 'url("assets/media/hero-poster-v084.jpg")';
    hero.style.backgroundSize = 'cover';
    hero.style.backgroundPosition = 'center';
  }
  function honorMotionPreference() {
    if (reduceMotion.matches) {
      video.pause(); video.removeAttribute('autoplay');
      hero.classList.remove('hero--end-card'); toggle.hidden = true;
    } else {
      toggle.hidden = false;
      var promise = video.play();
      if (promise && promise.catch) promise.catch(function () { updateButton(); if (video.networkState === 3) reportPlaybackError(); });
    }
    updateButton();
  }
  toggle.addEventListener('click', function () {
    if (video.paused) {
      var promise = video.play();
      if (promise && promise.catch) promise.catch(function () { updateButton(); });
    } else { video.pause(); hero.classList.remove('hero--end-card'); }
    updateButton();
  });
  video.addEventListener('timeupdate', syncEndCard);
  video.addEventListener('play', updateButton);
  video.addEventListener('pause', updateButton);
  video.addEventListener('error', reportPlaybackError);
  /* Claude QA: <source> 를 못 불러오면 video 가 아니라 source 에서 error 가 남 → 마지막 source 실패 = 대체 이미지 + 버튼 숨김 */
  var sources = video.getElementsByTagName('source');
  if (sources.length) sources[sources.length - 1].addEventListener('error', reportPlaybackError);
  video.addEventListener('emptied', updateButton);
  if (reduceMotion.addEventListener) reduceMotion.addEventListener('change', honorMotionPreference);
  honorMotionPreference();
  /* Claude QA: 스크립트가 늦게 실행돼 error 를 놓친 경우 (영상 없음 = NETWORK_NO_SOURCE) */
  if (video.networkState === 3) reportPlaybackError();
})();
