/* FINBRAIN — 4페이지 손가락으로 옆으로 넘기기 (핀브레인 · 코인바로 · 하우딱 · CJH GAMES) */
(function () {
  var PAGES = [
    { path: '', name: '핀브레인' },
    { path: 'coinbaro/', name: '코인바로' },
    { path: 'howddak/', name: '하우딱' },
    { path: 'cjhgames/', name: 'CJH GAMES' }
  ];
  var here = document.body.getAttribute('data-page');
  var idx = -1;
  for (var i = 0; i < PAGES.length; i++) if (PAGES[i].path === here) idx = i;
  if (idx < 0) return;
  var up = here === '' ? '' : '../';

  function go(to, dir) {
    if (to < 0 || to >= PAGES.length) return;
    try { sessionStorage.setItem('fb-swipe', dir); } catch (e) {}
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) { location.href = up + PAGES[to].path; return; }
    document.body.classList.add(dir === 'next' ? 'fb-out-left' : 'fb-out-right');
    setTimeout(function () { location.href = up + PAGES[to].path; }, 170);
  }

  // 들어올 때 방향 맞춰 살짝 밀려 들어오기
  try {
    var d = sessionStorage.getItem('fb-swipe');
    if (d) {
      sessionStorage.removeItem('fb-swipe');
      document.body.classList.add(d === 'next' ? 'fb-in-right' : 'fb-in-left');
      requestAnimationFrame(function () { requestAnimationFrame(function () {
        document.body.classList.remove('fb-in-right', 'fb-in-left');
      }); });
    }
  } catch (e) {}

  // 페이지 점 (지금 몇 번째 페이지인지)
  var nav = document.createElement('nav');
  nav.className = 'fb-dots';
  nav.setAttribute('aria-label', '페이지 이동');
  var prev = document.createElement('button');
  prev.className = 'fb-arrow'; prev.type = 'button'; prev.setAttribute('aria-label', '이전 페이지');
  prev.innerHTML = '&#8249;'; prev.disabled = idx === 0;
  prev.onclick = function () { go(idx - 1, 'prev'); };
  nav.appendChild(prev);
  PAGES.forEach(function (p, k) {
    var a = document.createElement('a');
    a.href = up + p.path;
    a.className = 'fb-dot' + (k === idx ? ' on' : '');
    a.setAttribute('aria-label', p.name);
    if (k === idx) a.setAttribute('aria-current', 'page');
    a.innerHTML = '<span>' + p.name + '</span>';
    a.onclick = function (ev) { if (k === idx) { ev.preventDefault(); return; } ev.preventDefault(); go(k, k > idx ? 'next' : 'prev'); };
    nav.appendChild(a);
  });
  var next = document.createElement('button');
  next.className = 'fb-arrow'; next.type = 'button'; next.setAttribute('aria-label', '다음 페이지');
  next.innerHTML = '&#8250;'; next.disabled = idx === PAGES.length - 1;
  next.onclick = function () { go(idx + 1, 'next'); };
  nav.appendChild(next);
  document.body.appendChild(nav);

  // 손가락으로 옆으로 밀기 (앱 화면 갤러리처럼 옆으로 스크롤되는 곳에서 시작하면 무시)
  var sx = 0, sy = 0, st = 0, tracking = false;
  document.addEventListener('touchstart', function (e) {
    if (e.touches.length !== 1) { tracking = false; return; }
    var t = e.target;
    while (t && t !== document.body) {
      if (t.classList && (t.classList.contains('gallery') || t.classList.contains('fb-noswipe'))) { tracking = false; return; }
      t = t.parentNode;
    }
    sx = e.touches[0].clientX; sy = e.touches[0].clientY; st = Date.now(); tracking = true;
  }, { passive: true });
  document.addEventListener('touchend', function (e) {
    if (!tracking) return;
    tracking = false;
    var dx = e.changedTouches[0].clientX - sx, dy = e.changedTouches[0].clientY - sy;
    if (Math.abs(dx) < 70 || Math.abs(dx) < Math.abs(dy) * 1.6 || Date.now() - st > 800) return;
    if (dx < 0) go(idx + 1, 'next'); else go(idx - 1, 'prev');
  }, { passive: true });

  // 키보드 ← →
  document.addEventListener('keydown', function (e) {
    if (e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
    if (e.key === 'ArrowRight') go(idx + 1, 'next');
    if (e.key === 'ArrowLeft') go(idx - 1, 'prev');
  });

  // 처음 한 번만 "옆으로 밀어서 이동" 안내 (휴대폰)
  try {
    if ('ontouchstart' in window && !localStorage.getItem('fb-swipe-hint')) {
      localStorage.setItem('fb-swipe-hint', '1');
      var h = document.createElement('div');
      h.className = 'fb-hint';
      h.textContent = '옆으로 밀면 다음 페이지로 넘어가요';
      document.body.appendChild(h);
      setTimeout(function () { h.classList.add('gone'); }, 2600);
    }
  } catch (e) {}
})();
